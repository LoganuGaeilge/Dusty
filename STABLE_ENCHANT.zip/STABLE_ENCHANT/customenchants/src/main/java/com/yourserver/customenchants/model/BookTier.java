package com.yourserver.customenchants.model;

/**
 * The three rarity tiers a book can come in. Each tier has its own
 * XP-level cost, loaded from config.yml at runtime (see EnchantManager).
 */
public enum BookTier {
    COMMON,
    RARE,
    LEGENDARY;

    public static BookTier fromString(String s) {
        if (s == null) return null;
        try {
            return BookTier.valueOf(s.trim().toUpperCase());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }
}
