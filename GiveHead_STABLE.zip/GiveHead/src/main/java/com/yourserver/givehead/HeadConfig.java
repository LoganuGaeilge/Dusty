package com.yourserver.givehead;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;

import java.util.HashMap;
import java.util.Map;

/**
 * Loads and resolves the "mob-heads:" mapping and "default-player:" fallback
 * from config.yml.
 *
 * Keys under mob-heads: are matched case-insensitively against a mob/entity
 * type name (e.g. "ZOMBIE", "zombie", "Zombie" all match the same entry).
 */
public final class HeadConfig {

    private final Map<String, String> mobHeads = new HashMap<>();
    private String defaultPlayer = "MHF_Steve";
    private boolean prettyPrintHeadNames = true;

    private String msgUsage = "&cUsage: /givehead <player> <mob-or-skin> <head name...>";
    private String msgPlayerNotFound = "&cThat player is not online.";
    private String msgGivenToTarget = "&aGave %target% a %head% head.";
    private String msgGivenConfirm = "&aYou received a %head% head.";
    private String msgReloaded = "&aGiveHead config reloaded.";

    public void load(FileConfiguration config) {
        mobHeads.clear();

        defaultPlayer = config.getString("default-player", defaultPlayer);
        prettyPrintHeadNames = config.getBoolean("pretty-print-head-names", prettyPrintHeadNames);

        if (config.isConfigurationSection("mob-heads")) {
            for (String key : config.getConfigurationSection("mob-heads").getKeys(false)) {
                String skin = config.getString("mob-heads." + key);
                if (skin != null && !skin.isBlank()) {
                    mobHeads.put(key.toUpperCase(), skin);
                }
            }
        }

        msgUsage = config.getString("messages.usage", msgUsage);
        msgPlayerNotFound = config.getString("messages.player-not-found", msgPlayerNotFound);
        msgGivenToTarget = config.getString("messages.given-to-target", msgGivenToTarget);
        msgGivenConfirm = config.getString("messages.given-confirm", msgGivenConfirm);
        msgReloaded = config.getString("messages.reloaded", msgReloaded);
    }

    /**
     * Resolves the "mob-or-skin" command argument into the offline-player
     * name whose texture should be used for the head.
     *
     * Resolution order:
     *   1. An explicit entry in "mob-heads:" (case-insensitive).
     *   2. If the token is a recognised entity/mob type but has no explicit
     *      entry, falls back to "default-player:".
     *   3. Otherwise the token is treated literally as an offline-player /
     *      skin name, exactly like the original Skript command.
     */
    public String resolveSkinName(String token) {
        String upper = token.toUpperCase();

        String mapped = mobHeads.get(upper);
        if (mapped != null) {
            return mapped;
        }

        if (isKnownEntityType(upper)) {
            return defaultPlayer;
        }

        return token;
    }

    private boolean isKnownEntityType(String upper) {
        try {
            EntityType.valueOf(upper);
            return true;
        } catch (IllegalArgumentException ex) {
            return false;
        }
    }

    public String getDefaultPlayer() {
        return defaultPlayer;
    }

    public boolean isPrettyPrintHeadNames() {
        return prettyPrintHeadNames;
    }

    /** All distinct skin names referenced by config (default-player + every mob-heads value). */
    public java.util.Set<String> getAllConfiguredSkinNames() {
        java.util.Set<String> names = new java.util.HashSet<>(mobHeads.values());
        names.add(defaultPlayer);
        return names;
    }

    public String msgUsage() {
        return msgUsage;
    }

    public String msgPlayerNotFound() {
        return msgPlayerNotFound;
    }

    public String msgGivenToTarget() {
        return msgGivenToTarget;
    }

    public String msgGivenConfirm() {
        return msgGivenConfirm;
    }

    public String msgReloaded() {
        return msgReloaded;
    }
}
