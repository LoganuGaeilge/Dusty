package com.yourserver.givehead;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.profile.PlayerProfile;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * /givehead <player> <mob-or-skin> <head name...>
 *
 * Same shape as the original Skript command: arg 1 is the receiving
 * (online) player, arg 2 identifies the skin (either a mob type resolved
 * through config.yml's "mob-heads:"/"default-player:", or a literal
 * offline-player/skin name), and everything from arg 3 onward is the head's
 * display name text (spaces allowed, no quotes needed) - " Head" is
 * appended automatically, exactly like the Skript version's
 * "%arg-3% Head".
 *
 * Skin textures are resolved through {@link SkinCache}, which uses the
 * Bukkit PlayerProfile API's update() to force a real Mojang name ->
 * UUID -> texture lookup - unlike Bukkit.getOfflinePlayer(name), which on
 * modern Spigot/Paper does NOT reliably do that for a name the server has
 * never seen, and silently falls back to a blank/default skin instead.
 *
 * Also handles "/givehead reload" (permission: givehead.admin) to reload
 * config.yml (and re-warm the skin cache) without a server restart.
 */
public final class GiveHeadCommand implements CommandExecutor, TabCompleter {

    private final GiveHeadPlugin plugin;

    public GiveHeadCommand(GiveHeadPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        HeadConfig cfg = plugin.getHeadConfig();

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("givehead.admin")) {
                sender.sendMessage(Text.color("&cYou don't have permission to do that."));
                return true;
            }
            plugin.reloadHeadConfig();
            sender.sendMessage(Text.color(cfg.msgReloaded()));
            return true;
        }

        if (args.length < 3) {
            sender.sendMessage(Text.color(cfg.msgUsage()));
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(Text.color(cfg.msgPlayerNotFound()));
            return true;
        }

        String mobOrSkin = args[1];
        String headNameText = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        if (cfg.isPrettyPrintHeadNames()) {
            headNameText = Text.prettifyMobToken(headNameText);
        }
        String skinName = cfg.resolveSkinName(mobOrSkin);

        giveHead(sender, target, skinName, headNameText);
        return true;
    }

    /**
     * Delivers the head, using an already-cached texture instantly if
     * available (the common case - config skins are pre-warmed on
     * startup/reload), otherwise resolving it asynchronously via
     * PlayerProfile#update() and hopping back to the main thread to
     * actually hand over the item (network calls must never touch the
     * main thread).
     */
    private void giveHead(CommandSender sender, Player target, String skinName, String headNameText) {
        SkinCache skins = plugin.getSkinCache();

        PlayerProfile cached = skins.getCached(skinName);
        if (cached != null) {
            deliver(sender, target, cached, headNameText);
            return;
        }

        String targetName = target.getName();
        skins.resolve(skinName).thenAcceptAsync(profile -> {
            Player stillOnline = Bukkit.getPlayerExact(targetName);
            if (stillOnline == null) {
                return; // they left before we could deliver it
            }
            deliver(sender, stillOnline, profile, headNameText);
        }, runnable -> Bukkit.getScheduler().runTask(plugin, runnable));
    }

    private void deliver(CommandSender sender, Player target, PlayerProfile profile, String headNameText) {
        HeadConfig cfg = plugin.getHeadConfig();
        ItemStack head = buildHead(profile, headNameText);

        Map<Integer, ItemStack> overflow = target.getInventory().addItem(head);
        if (!overflow.isEmpty()) {
            overflow.values().forEach(item ->
                    target.getWorld().dropItemNaturally(target.getLocation(), item));
        }

        String displayName = Text.color(headNameText + " Head");
        target.sendMessage(Text.color(cfg.msgGivenConfirm().replace("%head%", displayName)));
        if (sender != target) {
            sender.sendMessage(Text.color(cfg.msgGivenToTarget()
                    .replace("%target%", target.getName())
                    .replace("%head%", displayName)));
        }
    }

    private ItemStack buildHead(PlayerProfile profile, String headNameText) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta != null) {
            meta.setOwnerProfile(profile);
            meta.setDisplayName(Text.color(headNameText + " Head"));
            skull.setItemMeta(meta);
        }
        return skull;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 1) {
            List<String> options = Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .collect(Collectors.toList());
            options.add("reload");
            return filter(options, args[0]);
        }

        if (args.length == 2) {
            List<String> options = new ArrayList<>();
            for (EntityType type : EntityType.values()) {
                if (type.isAlive()) {
                    options.add(type.name());
                }
            }
            return filter(options, args[1]);
        }

        return List.of();
    }

    private List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase();
        return options.stream()
                .filter(option -> option.toLowerCase().startsWith(lower))
                .collect(Collectors.toList());
    }
}
